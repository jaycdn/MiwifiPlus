module ("yuneon.module.YNABOUT", package.seeall)

local YNFunction = require("yuneon.common.YNFunction")
local LuciUtil = require("luci.util")
local uci = require("luci.model.uci").cursor()

local YUNEONPATH = uci:get("yuneon", "miwifiplus", "path")

function aboutInfoGet()
	return uci:get("yuneon", "miwifiplus", "version")
end

function aboutMiwifiplusUpdate()
	os.execute("chmod +x " .. YUNEONPATH .. "/scripts/update.sh")
	return os.execute(YUNEONPATH .. "/scripts/update.sh") == 0
end

function aboutMiwifiplusRemove()
	os.execute("chmod +x " .. YUNEONPATH .. "/scripts/uninstall.sh")
	return os.execute(YUNEONPATH .. "/scripts/uninstall.sh") == 0
end